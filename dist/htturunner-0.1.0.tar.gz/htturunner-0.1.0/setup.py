# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['htturunner']

package_data = \
{'': ['*']}

install_requires = \
['httprunner>=2.3,<3.0',
 'jsonpath>=0.82.0,<0.83.0',
 'pyyaml>=5.1,<6.0',
 'requests>=2.22,<3.0',
 'selenium>=3.141,<4.0']

entry_points = \
{'console_scripts': ['hogrun = htturunner.cli:main']}

setup_kwargs = {
    'name': 'htturunner',
    'version': '0.1.0',
    'description': '接口测试',
    'long_description': None,
    'author': 'andong',
    'author_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
