import jsonpath
import requests

from htturunner.loader import load_yml


def extract_json_field(resp, json_field):
    value = jsonpath.jsonpath(resp.json(), json_field)
    return value[0]


def run_yaml(yml_file):
    load_json = load_yml(yml_file)
    request = load_json["request"]
    method = request.pop("method")
    url = request.pop("url")
    reps = requests.request(method, url, **request)
    validator_mapping = load_json["validate"]
    for key in validator_mapping:
        if "$" in key:
            actual_value = extract_json_field(reps, key)
        else:
            actual_value = getattr(reps, key)
        expected_value = validator_mapping[key]
        assert actual_value == expected_value
    print(load_json)
    return True
